# to make sure everything works fine
* run the "file.c" first. this will create a text file filled with data which other codes will read.
* if not done so, other programs will not find the text file and produce error.
